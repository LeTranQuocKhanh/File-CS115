import numpy as np
import pandas as pd

#  FUNCTION
def str_column_to_float(dataset,column):
    for row in dataset:
        row[column]=float(row[column])

def findMinMax(dataset):
    minmax = list()
    for i in range(len(dataset[0])):
        col_values = [row[i] for row in dataset]
        value_min = min(col_values)
        value_max = max(col_values)
        minmax.append([value_min, value_max])
    return minmax

def normalize_dataset(dataset):
    for i in range(len(dataset[0])):
        str_column_to_float(dataset, i)
    minmax = findMinMax(dataset)
    for row in dataset:
        for i in range(len(row) - 1):
            row[i] = (row[i] - minmax[i][0]) /(minmax[i][1] - minmax[i][0])
    return dataset

def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def filter(p):
    if(p >= 0.5):
        return 1
    return 0

def predict(x, w):
    return sigmoid(np.dot(x,w))

def cost_fuction(x, w, y):
    n = len(y)
    prediction = sigmoid(x.dot(w))
    cost =  - y * np.log(prediction) - ((1 - y).T * np.log(1 - prediction))
    return cost.sum() / n

def update_weight(x, w, y, learning_rate):
    n = len(y)
    prediction = sigmoid(x.dot(w))
    #print(prediction)
    w = w - learning_rate* np.dot(x.T,(prediction - y) / n)
    return w


def train(x, w, y, learning_rate, iter):
    for i in range(iter):
        if i % 1000 == 0:
            print(i)
        w = update_weight(x,w, y,learning_rate)
        cost =  cost_fuction(x, w, y)
        if( cost < 0.1):
            break
    return w

def setUpData(fileName):
    data = normalize_dataset(pd.read_csv(fileName,header=None).values)
    column = data.shape[1]
    row = data.shape[0]
    x = data[:, :column - 1]
    x = np.hstack((np.ones((row, 1)),x))
    y = data[:, column - 1].reshape(-1,1)
    return x , y ,row, column

def percent(x,w,y, row):
    count=0
    for index,value in enumerate(sigmoid(np.dot(x,w).reshape(-1,1))):
        if filter(value)==y[index]:
            count+=1
    return count / row


# TRAIN

x_train ,y_train, row_train , column_train = setUpData("dataToTrain.csv")
w = np.random.rand(9).reshape(-1,1)
learning_rate = 0.1
numberOfIteration = 20000
w = train(x_train, w, y_train , learning_rate , numberOfIteration)
print(w)

# TEST
x_test, y_test, row_test, column_test = setUpData("pima-indians-diabetes.data.csv")
print(str(percent(x_test, w, y_test, row_test)* 100) + "%" )
