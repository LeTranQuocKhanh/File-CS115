import numpy as np
import pandas as pd

#  FUNCTION
def str_column_to_float(dataset,column):
    for row in dataset:
        row[column]=float(row[column])

def findMinMax(dataset):
    minmax = list()
    for i in range(len(dataset[0])):
        col_values = [row[i] for row in dataset]
        value_min = min(col_values)
        value_max = max(col_values)
        minmax.append([value_min, value_max])
    return minmax

def normalize_dataset(dataset):
    for i in range(len(dataset[0])):
        str_column_to_float(dataset, i)
    minmax = findMinMax(dataset)
    for row in dataset:
        for i in range(len(row) - 1):
            row[i] = (row[i] - minmax[i][0]) /(minmax[i][1] - minmax[i][0])
    return dataset

def normalize_dataset_2(dataset, minmax):
    for row in dataset:
        for i in range(len(row) - 1):
            row[i] = (row[i] - minmax[i][0]) /(minmax[i][1] - minmax[i][0])
    return dataset

def setUpData(data):
    data = normalize_dataset(data)
    column = data.shape[1]
    row = data.shape[0]
    x = data[:, :column - 1]
    x = np.hstack((np.ones((row, 1)),x))
    y = data[:, column - 1].reshape(-1,1)
    return x , y ,row, column

def setUpData_2(data, minmax):
    data = normalize_dataset_2(data, minmax)
    column = data.shape[1]
    row = data.shape[0]
    x = data[:, :column - 1]
    x = np.hstack((np.ones((row, 1)),x))
    y = data[:, column - 1].reshape(-1,1)
    return x , y ,row, column

def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def filter(p):
    if(p >= 0.5):
        return 1
    return 0

def predict(x, w):
    return sigmoid(np.dot(x,w))

def cost_fuction(x, w, y , percent0, percent1):
    n = len(y)
    prediction = sigmoid(x.dot(w))
    cost =  - y * np.log(prediction)* percent1 - (1 - y)* np.log(1 - prediction) * percent0
    return cost.sum() / n

def aDotY(a, y):
    temp = np.ones((len(y), 1), dtype=float)
    for i in range(len(y)):
        temp[i] = a[i] * y[i]
    return temp



def update_weight(x, w, y, learning_rate , percent0, percent1):
    n = len(y)
    prediction = sigmoid(x.dot(w))
    #print(prediction)
    w = w - learning_rate* np.dot(x.T,(percent0*prediction - percent1 *y - (percent0 - percent1) *prediction*y)) / n
    return w


def train(x, w, y, learning_rate, iter, percent0, percent1):
    for i in range(iter):
        if i % 1000 == 0:
            print(i)
        w = update_weight(x,w, y,learning_rate , percent0, percent1)
        cost =  cost_fuction(x, w, y, percent0, percent1)
        if( cost < 0.1):
            break
    return w



def percent(x,w,y, row):
    count=0
    for index,value in enumerate(sigmoid(np.dot(x,w).reshape(-1,1))):
        if filter(value)==y[index]:
            count+=1
    return count / row

def confusion_matrix( x,w,y):
    TN = 0
    TP = 0
    FN = 0
    FP = 0
    for index,value in enumerate(sigmoid(np.dot(x,w).reshape(-1,1))):
        print(value)
        if y[index] == 0:
            if filter(value) == 0:
                TN += 1
            else:
                FP +=1
        else:
            if filter(value) == 0:
                FN +=1
            else:
                TP += 1
    return  TN, TP, FN, FP


fileName1 ="processed.cleveland.data"
fileName2 = 'reprocessed.hungarian.data'
data1 = pd.read_csv(fileName1 ,header=None).values
data2 = pd.read_csv(fileName2, sep=',', delimiter=' ',header=None).values
data = np.concatenate((data1, data2))

for i in range(len(data[0])):
        str_column_to_float(data, i)

column = data.shape[1]
row = data.shape[0]
# print(row)

# TRAIN
rowToTrain = int(row * 0.8)
dataTrain = data[:rowToTrain,:]

# MIN _ MAX

minmax = findMinMax(dataTrain)

x_train ,y_train, row_train , column_train = setUpData(dataTrain)
# print(row_train)
value1 = 0
for i in y_train:
    if i[0] != 0:
        value1 += 1
        i[0] = 1
value0 = row_train - value1
# print("Value 0:" + str(value0))
# print("Value 1:" + str(value1))
percent0 = float(1/ (1 + value0/ value1))
percent1 = 1 - percent0
# print(percent0)
# print(percent1)

w = np.random.rand(column_train).reshape(-1,1)
# print(w)
learning_rate = 0.01
numberOfIteration = 20000
# w = train(x_train, w, y_train , learning_rate , numberOfIteration, percent0, percent1)
w = train(x_train, w, y_train , learning_rate , numberOfIteration, percent0, percent1)

# print(w)
# TEST
dataTest = data[rowToTrain:,:]
# print(dataTest)
x_test, y_test, row_test, column_test = setUpData_2(dataTest, minmax)
# print(x_test)
value1_test = 0
for i in y_test:
    if i[0] != 0:
        value1_test += 1
        i[0] = 1
# print(value1_test)
# print(row_test - value1_test)

TN, TP, FN, FP = confusion_matrix(x_test, w, y_test)
# print("TN: "+ str(TN) + " TP: " + str(TP) + " FN: " + str(FN) +" FP: " + str(FP))
Matrix = np.array([[TP,FP], [FN,TN]])
print("\nConfusion matrix: ")
print(Matrix)
accuracy = (TP + TN) / (TP + TN + FP +FN)
precison = TP / (TP + FP)
recall = TP/ (TP+ FN)
F1 = 2* (precison* recall) / (precison + recall)
print("Accuracy: " + str(accuracy * 100))
print("Precison: " + str(precison* 100))
print("Recall: " + str(recall* 100))
print("F1: " + str(F1* 100))
print('\n')
